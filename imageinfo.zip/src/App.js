import React from 'react';
import './App.css';
import Imageloader from './Imageloader';

function App() {
  return (
    <div>
      <Imageloader/>
    </div>
  );
}

export default App;
